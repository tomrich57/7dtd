# Donovan CraftBeaker

## 7 Days 2 Die Modlet

This small modlet adds the Beaker to the list of craftable items in your forge w/ crucible.
